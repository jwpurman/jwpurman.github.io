<?php

defined( 'ABSPATH' ) || exit;

interface The7_Option_Field_Composition_Interface {
	public function with_interface( The7_Options_Interface $interface );
}